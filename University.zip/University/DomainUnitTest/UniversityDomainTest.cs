using System;
using System.Collections.Generic;
using NUnit.Framework;
using Domain;
using Domain.Common;

namespace DomainUnitTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void StudentCannotBeCreatedWithoutFirstName()
        {
            try
            {
                //Assign

                //Act
                var student = new Student("", "Test", "test@gmail.com");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.StudentModelValidation.StudentFirstNameCannotBeEmpty));
            }
        }

        [Test]
        public void StudentCannotBeCreatedWithoutLastName()
        {
            try
            {
                //Assign

                //Act
                var student = new Student("Test", "", "test@gmail.com");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.StudentModelValidation.StudentLastNameCannotBeEmpty));
            }
        }

        [Test]
        public void StudentCannotBeCreatedWithoutEmail()
        {
            try
            {
                //Assign

                //Act
                var student = new Student("Test", "Name", "");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.StudentModelValidation.StudentEmailCannotBeEmpty));
            }
        }


        [Test]
        public void StudentCannotBeCreatedWithInvalidEmail()
        {
            try
            {
                //Assign

                //Act
                var student = new Student("Test", "Name", "test.com");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.StudentModelValidation.StudentEmailIsInvalid));
            }
        }

        [Test]
        public void StudentCannotEnrollToSameSubjectTwice()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var schedule2 = new Schedule(DayOfWeek.Tuesday, scheduleStartTime, scheduleEndTime);
                var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
                var lectureLocation2 = new LectureTheatre(15, "Theatre2", true);
                schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));
                schedule2.AllocateLecture("TestLecture2", lectureLocation2, new DateTime(2022, 3, 22));
                var student = new Student("Test", "Name", "test@gmail.com");
                var subject1 = new Subject("Subject1", new List<Schedule> { schedule1, schedule2 });

                //Act
                student.Enroll(subject1);
                student.Enroll(subject1);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is StudentDuplicateEnrollmentException);
            }
        }

        [Test]
        public void StudentCannotAttendASubjectMoreThan10HoursPerWeek()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(15, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var schedule2 = new Schedule(DayOfWeek.Tuesday, scheduleStartTime, scheduleEndTime);
                var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
                var lectureLocation2 = new LectureTheatre(15, "Theatre2", true);
                schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));
                schedule2.AllocateLecture("TestLecture2", lectureLocation2, new DateTime(2022, 3, 22));
                var student = new Student("Test", "Name", "test@gmail.com");
                var subject1 = new Subject("Subject1", new List<Schedule> { schedule1, schedule2 });

                //Act
                student.Enroll(subject1);
            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is StudentEnrollmentHoursExceededException);
            }
        }

        [Test]
        public void StudentCannotEnrollWhenLEctureTheatreCapacityHasExceeded()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var schedule2 = new Schedule(DayOfWeek.Tuesday, scheduleStartTime, scheduleEndTime);
                var lectureLocation1 = new LectureTheatre(2, "Theatre1", false);
                var lectureLocation2 = new LectureTheatre(2, "Theatre2", true);
                schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));
                schedule2.AllocateLecture("TestLecture2", lectureLocation2, new DateTime(2022, 3, 22));
                var student1 = new Student("Test1", "Name1", "test1@gmail.com");
                var student2 = new Student("Test2", "Name2", "test2@gmail.com");
                var student3 = new Student("Test3", "Name3", "test3@gmail.com");

                var subject1 = new Subject("Subject1", new List<Schedule> { schedule1, schedule2 });

                //Act
                student1.Enroll(subject1);
                student2.Enroll(subject1);
                student3.Enroll(subject1);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is StudentCannotEnrollDueToLimitedCapacityException);
            }
        }

        [Test]
        public void StudentSuccessfulEnrollmentToSubject()
        {
            //Assign
            var scheduleStartTime = new TimeSpan(9, 0, 0);
            var scheduleEndTime = new TimeSpan(10, 0, 0);
            var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
            var schedule2 = new Schedule(DayOfWeek.Tuesday, scheduleStartTime, scheduleEndTime);
            var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
            var lectureLocation2 = new LectureTheatre(15, "Theatre2", true);
            schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));
            schedule2.AllocateLecture("TestLecture2", lectureLocation2, new DateTime(2022, 3, 22));
            var student = new Student("Test", "Name", "test@gmail.com");
            var subject1 = new Subject("Subject1", new List<Schedule> { schedule1, schedule2 });

            //Act
            student.Enroll(subject1);

            //Assert 
            Assert.IsTrue(student.EnrolledSubjects.Count == 1);
        }

        [Test]
        public void SubjectCannoteBeCreatedWithoutName()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var schedule2 = new Schedule(DayOfWeek.Tuesday, scheduleStartTime, scheduleEndTime);

                //Act
                var subject = new Subject("", new List<Schedule> { schedule1, schedule2 });

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.SubjectModelValidation.SubjectNameCannotBeEmpty));
            }
        }

        [Test]
        public void SubjectCannotBeCreatedWithoutSchedule()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var schedule2 = new Schedule(DayOfWeek.Tuesday, scheduleStartTime, scheduleEndTime);

                //Act
                var subject = new Subject("TestSubject", null);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.SubjectModelValidation.SubjectMustHaveAtleastOneSchedule));
            }
        }

        [Test]
        public void DuplicateScheduleCannotBeAddedToSubject()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var schedule2 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);

                //Act
                var subject = new Subject("TestSubject", new List<Schedule>() { schedule1, schedule2 });

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is SubjectDuplicateScheduleAdditionException);
            }
        }


        [Test]
        public void ScheduleCannoteBeCreatedWithoutStartTime()
        {
            try
            {
                //Assign

                //Act
                var schedule = new Schedule(DayOfWeek.Monday, TimeSpan.Zero, new TimeSpan(10, 0, 0));

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.ScheduleModelValidation.ScheduleStartTimeCannotBeEmpty));
            }
        }

        [Test]
        public void ScheduleCannoteBeCreatedWithoutEndTime()
        {
            try
            {
                //Assign

                //Act
                var schedule = new Schedule(DayOfWeek.Monday, new TimeSpan(9, 0, 0), TimeSpan.Zero);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.ScheduleModelValidation.ScheduleEndTimeCannotBeEmpty));
            }
        }



        [Test]
        public void ScheduleDayAndLectureAllocationDateHasToFallOnSameDayOfWeek()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
                var subject1 = new Subject("Subject1", new List<Schedule> { schedule1 });

                //Act
                schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 19));

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is ScheduleDayCannotBeDifferentFromAllocatedLectureDayOfWeek);
            }
        }

        [Test]
        public void LectureCannotBeAllocatedToSameScheduleSpotForADayTwice()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
                var lectureLocation2 = new LectureTheatre(15, "Theatre2", true);
                var subject1 = new Subject("Subject1", new List<Schedule> { schedule1 });

                //Act
                schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));
                schedule1.AllocateLecture("TestLecture2", lectureLocation2, new DateTime(2022, 3, 21));

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is ScheduleLectureAlreadyAllocatedOnTheDate);
            }
        }

        [Test]
        public void SuccessfulAllocationOfLectureToSchedule()
        {
            //Assign
            var scheduleStartTime = new TimeSpan(9, 0, 0);
            var scheduleEndTime = new TimeSpan(10, 0, 0);
            var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
            var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
            var subject1 = new Subject("Subject1", new List<Schedule> { schedule1 });

            //Act
            schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));

            //Assert
            Assert.IsTrue(schedule1.Lectures.Count == 1);
        }

        [Test]
        public void LectureTheatreCannoteBeCreatedNumberOfSeats()
        {
            try
            {
                //Assign

                //Act
                var lectureTheatre = new LectureTheatre(0, "Theatre1");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.LectureTheatreModelValidation.LectureTheatreNoOfSeatsHasToBeGreaterThanZero));
            }
        }

        [Test]
        public void LectureTheatreCannoteBeCreatedWithoutName()
        {
            try
            {
                //Assign

                //Act
                var lectureTheatre = new LectureTheatre(5, "");

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex.Message.Equals(Constants.LectureTheatreModelValidation.LectureTheatreNameCannotBeEmpty));
            }
        }

        [Test]
        public void TwoDifferentLecturesCannotBeConductedInTheatreOnSameDateAndTime()
        {
            try
            {
                //Assign
                var scheduleStartTime = new TimeSpan(9, 0, 0);
                var scheduleEndTime = new TimeSpan(10, 0, 0);
                var schedule1 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var lectureLocation1 = new LectureTheatre(10, "Theatre1", false);
                var subject1 = new Subject("Subject1", new List<Schedule> { schedule1 });

                var schedule2 = new Schedule(DayOfWeek.Monday, scheduleStartTime, scheduleEndTime);
                var subject2 = new Subject("Subject2", new List<Schedule> { schedule2 });

                //Act
                schedule1.AllocateLecture("TestLecture1", lectureLocation1, new DateTime(2022, 3, 21));
                schedule2.AllocateLecture("TestLecture2", lectureLocation1, new DateTime(2022, 3, 21));
            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is TheatreCannotHostDifferentLectureOnSameTimeAndDate);
            }
        }
    }
}