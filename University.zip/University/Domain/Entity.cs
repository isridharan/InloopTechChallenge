﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Domain
{
    public abstract class Entity
    {
        [Key]
        public Guid Id { get; set; }
        public abstract override bool Equals(object obj);
        public abstract override int GetHashCode();
    }
}
