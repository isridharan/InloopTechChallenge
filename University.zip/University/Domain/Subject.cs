﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Common;

namespace Domain
{
    public class Subject : Entity
    {
        private Subject()
        {

        }

        public Subject(string subjectName, IList<Schedule> schedules)
        {
            this.SubjectName = string.IsNullOrEmpty(subjectName)
                ? throw new ArgumentException(
                    Constants.SubjectModelValidation.SubjectNameCannotBeEmpty)
                : subjectName;
            if (schedules == null || schedules.Count == 0)
            {
                throw new ArgumentException(
                    Constants.SubjectModelValidation.SubjectMustHaveAtleastOneSchedule);
            }

            this.Schedules = new List<Schedule>();
            this.RegisteredStudents = new List<Student>();
            AddSchedule(schedules);
        }
        public string SubjectName { get; protected set; }
        public IList<Student> RegisteredStudents { get; protected set; }
        public IList<Schedule> Schedules { get; protected set; }


        private void AddSchedule(IList<Schedule> schedules)
        {
            schedules.ToList().ForEach(scheduleToBeAdded =>
            {
                if (this.Schedules.Any(existingSchedule => existingSchedule.Equals(scheduleToBeAdded)))
                    throw new SubjectDuplicateScheduleAdditionException(
                        $"schedule already exists for {scheduleToBeAdded.DayOfWeek} between {scheduleToBeAdded.StartTime} and {scheduleToBeAdded.EndTime} for the subject {this.SubjectName}");
                scheduleToBeAdded.AddSubject(this);
                this.Schedules.Add(scheduleToBeAdded);
            });
        }

        private void AddSchedule(Schedule schedule)
        {
            schedule.AddSubject(this);
            this.Schedules.Add(schedule);
        }

        public bool Equals(Subject subject)
        {
            return this.Id == subject.Id && this.SubjectName == subject.SubjectName;
        }

        public override bool Equals(object obj)
        {
            var subject = (Subject)obj;
            if (subject != null)
            {
                return this.Id == subject.Id && this.SubjectName == subject.SubjectName;
            }
            return false;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }

        private int TotalHoursAllocatedWeeklyForTheSubject
        {
            get { return this.Schedules.Sum(existingSchedule => existingSchedule.DurationInHours); }
        }

        private bool CanAnymoreStudentsBeRegistered()
        {
            return this.Schedules.All(existingSchedule =>
                existingSchedule.MinimumCapacityOfAllLectureTheatre > this.RegisteredStudents.Count);
        }

        public void Register(Student student)
        {
            // check if subject already has student registered
            if (RegisteredStudents.Any(existingStudent => existingStudent.Equals(student)))
            {
                throw new StudentDuplicateEnrollmentException(
                    $"The student {student.FullName} has already enrolled in to the subject {this.SubjectName}");
            }

            if (this.TotalHoursAllocatedWeeklyForTheSubject > Constants.MaxStudentHoursAllowedPerWeekBySubject)
            {
                throw new StudentEnrollmentHoursExceededException(
                    $"Total hours enrolled by the student exceeds {Convert.ToString(Constants.MaxStudentHoursAllowedPerWeekBySubject)} hours");
            }

            if (this.CanAnymoreStudentsBeRegistered())
            {
                this.RegisteredStudents.Add(student);
            }
            else
            {
                throw new StudentCannotEnrollDueToLimitedCapacityException(
                    $"Students cannot enroll to this subject due to the limited capacity of lecture hall");
            }
        }
    }
}
