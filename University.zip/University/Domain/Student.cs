﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Domain.Common;

namespace Domain
{
    public class Student : Entity
    {
        private Student()
        {

        }

        public Student(string firstName, string lastName, string email)
        {
            this.FirstName = string.IsNullOrEmpty(firstName)
                ? throw new ArgumentException(Constants.StudentModelValidation.StudentFirstNameCannotBeEmpty)
                : firstName;
            this.LastName = string.IsNullOrEmpty(lastName)
                ? throw new ArgumentException(
                    Constants.StudentModelValidation.StudentLastNameCannotBeEmpty)
                : lastName;
            this.Email = string.IsNullOrEmpty(email)
                ? throw new ArgumentException(
                    Constants.StudentModelValidation.StudentEmailCannotBeEmpty)
                : ValidateEmail(email);
            this.EnrolledSubjects = new List<Subject>();
        }

        public string FirstName { get; protected set; }
        public string LastName { get; protected set; }
        public string Email { get; protected set; }
        public IList<Subject> EnrolledSubjects { get; protected set; }
        public string FullName => this.FirstName + ", " + this.LastName + "(" + this.Email + ")";

        public string ValidateEmail(string email)
        {
            if (!Regex.IsMatch(email, Constants.EmailRegex))
                throw new Exception(
                    Constants.StudentModelValidation.StudentEmailIsInvalid);
            return email;
        }

        public void Enroll(Subject subject)
        {
            // check if student already enrolled into this subject
            if (EnrolledSubjects.Any(existingSubject => existingSubject.Equals(subject)))
            {
                throw new StudentDuplicateEnrollmentException(
                    $"The student {this.FullName} has already enrolled in to the subject {subject.SubjectName}");
            }

            subject.Register(this);
            this.EnrolledSubjects.Add(subject);
        }

        public override bool Equals(object obj)
        {
            var student = (Student)obj;
            if (student != null)
            {
                return this.Id == student.Id && this.Email == student.Email;
            }
            return false;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
    }

}
