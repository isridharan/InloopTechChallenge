﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Lecture : Entity
    {
        private Lecture()
        {

        }
        public Lecture(string name, LectureTheatre location, DateTime dateOfLecture)
        {
            this.Name = string.IsNullOrEmpty(name) ? throw new ArgumentException(
                $"The lecture name cannot be empty.") : name;
            this.Location = location ?? throw new ArgumentException(
                $"The lecture location cannot be empty.");
            this.DateOfLecture = dateOfLecture == default
                ? throw new ArgumentException(
                    $"The date of lecture cannot be empty.")
                : dateOfLecture;
        }
        public string Name { get; set; }
        public LectureTheatre Location { get; protected set; }
        public DateTime DateOfLecture { get; protected set; }
        public DateTime StartTime => this.DateOfLecture.Date.Add(this.Schedule.StartTime);
        public DateTime EndTime => this.DateOfLecture.Date.Add(this.Schedule.EndTime);
        public Schedule Schedule { get; protected set; }

        public bool Equals(Lecture lecture)
        {
            return this.Schedule.Id == lecture.Schedule.Id && this.Name == lecture.Name && DateTime.Compare(this.DateOfLecture, lecture.DateOfLecture) == 0;
        }

        public override bool Equals(object obj)
        {
            var lecture = (Lecture)obj;
            if (lecture != null)
            {
                return this.Schedule.Id == lecture.Schedule.Id && this.Name == lecture.Name && DateTime.Compare(this.DateOfLecture, lecture.DateOfLecture) == 0;
            }
            return false;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }

        public void AddSchedule(Schedule schedule)
        {
            this.Schedule = schedule;
        }

        public bool IsAllocated(DateTime dateOfLecture)
        {
            return DateTime.Compare(this.DateOfLecture, dateOfLecture) == 0;
        }
    }
}
