﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Common
{
    public class StudentDuplicateEnrollmentException : Exception
    {
        public StudentDuplicateEnrollmentException(string message)
            : base(message)
        {
        }
    }


    public class StudentEnrollmentHoursExceededException : Exception
    {
        public StudentEnrollmentHoursExceededException(string message)
            : base(message)
        {
        }
    }

    public class StudentCannotEnrollDueToLimitedCapacityException : Exception
    {
        public StudentCannotEnrollDueToLimitedCapacityException(string message)
            : base(message)
        {
        }
    }

    public class SubjectDuplicateScheduleAdditionException : Exception
    {
        public SubjectDuplicateScheduleAdditionException(string message)
            : base(message)
        {
        }
    }


    public class ScheduleDayCannotBeDifferentFromAllocatedLectureDayOfWeek : Exception
    {
        public ScheduleDayCannotBeDifferentFromAllocatedLectureDayOfWeek(string message)
            : base(message)
        {
        }
    }

    public class ScheduleLectureAlreadyAllocatedOnTheDate : Exception
    {
        public ScheduleLectureAlreadyAllocatedOnTheDate(string message)
            : base(message)
        {
        }
    }

    public class TheatreCannotHostDifferentLectureOnSameTimeAndDate : Exception
    {
        public TheatreCannotHostDifferentLectureOnSameTimeAndDate(string message)
            : base(message)
        {
        }
    }
}
