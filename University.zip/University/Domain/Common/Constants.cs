﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Common
{
    public class Constants
    {
        public const string EmailRegex =
            @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
        public const int MaxStudentHoursAllowedPerWeekBySubject = 10;
        public struct StudentModelValidation
        {
            public const string StudentFirstNameCannotBeEmpty = "The student FirstName cannot be empty.";
            public const string StudentLastNameCannotBeEmpty = "The student LastName cannot be empty.";
            public const string StudentEmailCannotBeEmpty = "The student Email cannot be empty.";
            public const string StudentEmailIsInvalid = "The student Email is invalid.";
        }

        public struct SubjectModelValidation
        {
            public const string SubjectNameCannotBeEmpty = "The subject name cannot be empty.";
            public const string SubjectMustHaveAtleastOneSchedule = "The subject has to have atleast one schedule.";
        }

        public struct ScheduleModelValidation
        {
            public const string ScheduleStartTimeCannotBeEmpty = "The schedule start time cannot be empty.";
            public const string ScheduleEndTimeCannotBeEmpty = "The schedule end time cannot be empty.";
        }

        public struct LectureTheatreModelValidation
        {
            public const string LectureTheatreNoOfSeatsHasToBeGreaterThanZero = "The numberOfSeats cannot be zero.";
            public const string LectureTheatreNameCannotBeEmpty = "The lecture theatre name cannot be empty.";
        }
    }
}
