﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Common;

namespace Domain
{
    public class Schedule : Entity
    {
        private Schedule()
        {

        }

        public Schedule(DayOfWeek dayOfWeek, TimeSpan startTime, TimeSpan endTime)
        {
            this.DayOfWeek = dayOfWeek;
            this.StartTime = startTime == default ? throw new ArgumentException(
                Constants.ScheduleModelValidation.ScheduleStartTimeCannotBeEmpty) : startTime;
            this.EndTime = endTime == default ? throw new ArgumentException(
                Constants.ScheduleModelValidation.ScheduleEndTimeCannotBeEmpty) : endTime;
            this.Lectures = new List<Lecture>();
        }
        public DayOfWeek DayOfWeek { get; protected set; }
        public TimeSpan StartTime { get; protected set; }
        public TimeSpan EndTime { get; protected set; }
        public int DurationInHours
        {
            get
            {
                var span = EndTime - StartTime;
                return span.Hours;
            }
        }
        public IList<Lecture> Lectures { get; protected set; }
        public Subject Subject { get; protected set; }

        public bool Equals(Schedule schedule)
        {
            return this.DayOfWeek == schedule.DayOfWeek && this.StartTime == schedule.StartTime &&
                   this.EndTime == schedule.EndTime;
        }

        public override bool Equals(object obj)
        {
            var schedule = (Schedule)obj;
            if (schedule != null)
            {
                return this.DayOfWeek == schedule.DayOfWeek && this.StartTime == schedule.StartTime &&
                       this.EndTime == schedule.EndTime;
            }
            return false;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }

        public void AddSubject(Subject subject)
        {
            this.Subject = subject;
        }

        public int MinimumCapacityOfAllLectureTheatre
        {
            get { return this.Lectures.Select(existingLecture => existingLecture.Location.NumberOfSeats).Min(); }
        }

        public bool IsLectureAllocatedForTheSlot(DateTime dateOfLecture)
        {
            return this.Lectures.Any(existingLecture => existingLecture.IsAllocated(dateOfLecture));
        }

        public void AllocateLecture(string name, LectureTheatre location, DateTime dateOfLecture)
        {
            if (dateOfLecture.DayOfWeek != DayOfWeek)
            {
                throw new ScheduleDayCannotBeDifferentFromAllocatedLectureDayOfWeek(
                    $"Lecture is allocated on {dateOfLecture.DayOfWeek} which is different from schedule day {this.DayOfWeek}");
            }
            var startTime = dateOfLecture.Date.Add(this.StartTime);
            var endTime = dateOfLecture.Date.Add(this.EndTime);
            if (IsLectureAllocatedForTheSlot(dateOfLecture))
            {
                throw new ScheduleLectureAlreadyAllocatedOnTheDate(
                    $"Lecture has already been allocated for the subject {Subject.SubjectName} between {startTime} to {endTime}");
            }
            var lecture = new Lecture(name, location, dateOfLecture);
            lecture.AddSchedule(this);
            location.AddLecture(lecture);
            this.Lectures.Add(lecture);
        }
    }
}
