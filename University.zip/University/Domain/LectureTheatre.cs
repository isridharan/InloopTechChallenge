﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Common;

namespace Domain
{
    public class LectureTheatre : Entity
    {
        private LectureTheatre()
        {

        }
        public LectureTheatre(int numberOfSeats, string name, bool isVirtualEnabled = false)
        {
            this.NumberOfSeats = numberOfSeats == default ? throw new ArgumentException(
                Constants.LectureTheatreModelValidation.LectureTheatreNoOfSeatsHasToBeGreaterThanZero) : numberOfSeats;
            this.Name = string.IsNullOrEmpty(name) ? throw new ArgumentException(
                Constants.LectureTheatreModelValidation.LectureTheatreNameCannotBeEmpty) : name;
            this.IsVirtualEnabled = isVirtualEnabled;
            this.Lectures = new List<Lecture>();
        }
        public int NumberOfSeats { get; protected set; }
        public string Name { get; protected set; }
        public bool IsVirtualEnabled { get; protected set; }
        public List<Lecture> Lectures { get; protected set; }

        public override bool Equals(object obj)
        {
            var lectureTheatre = (LectureTheatre)obj;
            if (lectureTheatre != null)
            {
                return this.Id == lectureTheatre.Id && this.Name == lectureTheatre.Name;
            }
            return false;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }

        public void AddLecture(Lecture lecture)
        {
            if (this.Lectures.Any(existingLecture => existingLecture.Equals(lecture)))
            {
                throw new Exception(
                    $"The lecture {lecture.Name} is already added to the theatre {this.Name}.");
            }
            // check if any other lecture happens at same time and date in the lecture theatre.
            if (this.Lectures.Any(existingLecture =>
                    existingLecture.DateOfLecture == lecture.DateOfLecture &&
                    existingLecture.StartTime >= lecture.StartTime &&
                    existingLecture.EndTime <= lecture.EndTime
                ))
            {
                throw new TheatreCannotHostDifferentLectureOnSameTimeAndDate(
                    $"The lecture theatre {Name} is already booked between {lecture.StartTime} and {lecture.EndTime }");
            }

            this.Lectures.Add(lecture);
        }
    }

}
