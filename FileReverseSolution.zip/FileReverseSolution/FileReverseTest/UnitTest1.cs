using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using FileReverseConsole;
using FileReverseConsole.Domain;
using FileReverseConsole.Service;
using NUnit.Framework;

namespace FileReverseTest
{
    public class Tests
    {
        private readonly IFileService _fileservice;

        public Tests()
        {
            _fileservice = new FileService();
        }

        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void ReadFileNotImplemented()
        {
            try
            {
                //Act
                var read = _fileservice.ReadFile("C:\\UnitTestFile\\File.txt");

                //Assert
                Assert.IsTrue(read.Length > 0);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is NotImplementedException);
            }
        }

        [Test]
        public void ReadFileDirectoryNotFound()
        {
            try
            {
                //Act
                var read = _fileservice.ReadFile("C:\\UnitTestFile\\File.txt");

                //Assert
                Assert.IsTrue(read.Length > 0);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is DirectoryNotFoundException);
            }
        }

        [Test]
        public void ReadFileOperationFileNotFound()
        {
            try
            {
                //Act
                var read = _fileservice.ReadFile("C:\\UnitTestFile\\File.txt");

                //Assert
                Assert.IsTrue(read.Length > 0);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is FileNotFoundException);
            }
        }

        [Test]
        public void ReadFileOperationEmptyFile()
        {
            try
            {
                //Act
                var read = _fileservice.ReadFile("C:\\UnitTestFile\\File.txt");

                //Assert
                Assert.IsTrue(read.Length > 0);

            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is EmptyFileException);
            }
        }



        [Test]
        public void ReadFile()
        {
            try
            {
                //Act
                var read = _fileservice.ReadFile("C:\\UnitTestFile\\File.txt");

                //Assert
                Assert.IsTrue(read.Length > 0);
                
            }
            catch (Exception ex)
            {
               //No Exception and Successful
            }
        }

        //Test the strategy returned for 0 line.
        //Reverse Every Line and Test
        [Test]
        public void StrategyReturnedFor0LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>();

                //Act
                var content = new FileContent(stringContent.ToArray());
                var reverseContent = content.ReversedContent;
                var strategy = content.StrategyName;
            }
            catch (Exception ex)
            {
                //Assert
                Assert.IsTrue(ex is CannotCreateFileContentWithoutLines);
            }
        }


        //Test the strategy returned for 1 line.
        //Reverse Every Line and Test
        [Test]
        public void StrategyReturnedFor1LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var reverseContent = content.ReversedContent;
                var strategy = content.StrategyName;

                //Assert
                Assert.IsTrue(reverseContent is { Count: > 0 });
                Assert.IsTrue(strategy.Equals(FileContent.ReverseStrategies.ReverseStrategy.ToString()));
            }
            catch (Exception ex)
            {

            }
        }

        //Test the strategy returned for 3 lines.
        //Reverse Every Line and Test
        [Test]
        public void StrategyReturnedFor3LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1",
                    "Test Line 2",
                    "Test Line 3"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var reverseContent = content.ReversedContent;
                var strategy = content.StrategyName;

                //Assert
                Assert.IsTrue(reverseContent is { Count: > 0 });
                Assert.IsTrue(strategy.Equals(FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString()));
            }
            catch (Exception ex)
            {

            }
        }

        //Test the strategy returned for greater than 3 lines.
        //Reverse Every Line and Test
        [Test]
        public void StrategyReturnedForGreaterThan3LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1",
                    "Test Line 2",
                    "Test Line 3",
                    "Test Line 4"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var reverseContent = content.ReversedContent;
                var strategy = content.StrategyName;

                //Assert
                Assert.IsTrue(reverseContent is { Count: > 0 });
                Assert.IsTrue(strategy.Equals(FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString()));
            }
            catch (Exception ex)
            {

            }
        }

        //Reverse Every Line and Test 1 Line Content
        [Test]
        public void ReverseAndTest1LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var originalContent = content.OriginalContent;
                var reverseContent = content.ReversedContent;

                //Assert
                Assert.IsTrue(originalContent is {Count: > 0});
                Assert.IsTrue(reverseContent is { Count: > 0 });
                originalContent.ToList().ForEach(line =>
                {
                    var originalIndex = originalContent.IndexOf(line);
                    var reversedIndex = originalIndex;
                    var toCharArray = line.ToCharArray();
                    Array.Reverse(toCharArray);
                    if (content.StrategyName == FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString())
                    {
                        if (originalIndex == 0)
                        {
                            reversedIndex = originalContent.Count - 1;
                        }
                        else if (originalIndex == originalContent.Count - 1)
                        {
                            reversedIndex = 0;
                        }
                    }

                    var valueToCompare = reverseContent[reversedIndex];
                    Assert.IsTrue(valueToCompare.Equals(new string(toCharArray)));
                });
            }
            catch (Exception ex)
            {

            }
        }

        //Reverse Every Line and Test 2 Line Content
        [Test]
        public void ReverseAndTest2LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1",
                    "Test Line 2"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var originalContent = content.OriginalContent;
                var reverseContent = content.ReversedContent;

                //Assert
                Assert.IsTrue(originalContent is { Count: > 0 });
                Assert.IsTrue(reverseContent is { Count: > 0 });
                originalContent.ToList().ForEach(line =>
                {
                    var originalIndex = originalContent.IndexOf(line);
                    var reversedIndex = originalIndex;
                    var toCharArray = line.ToCharArray();
                    Array.Reverse(toCharArray);
                    if (content.StrategyName == FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString())
                    {
                        if (originalIndex == 0)
                        {
                            reversedIndex = originalContent.Count - 1;
                        }
                        else if (originalIndex == originalContent.Count - 1)
                        {
                            reversedIndex = 0;
                        }
                    }

                    var valueToCompare = reverseContent[reversedIndex];
                    Assert.IsTrue(valueToCompare.Equals(new string(toCharArray)));
                });
            }
            catch (Exception ex)
            {

            }
        }

        //Reverse Every Line and Test 3 Line Content
        [Test]
        public void ReverseAndTest3LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1",
                    "Test Line 2",
                    "Test Line 3"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var originalContent = content.OriginalContent;
                var reverseContent = content.ReversedContent;

                //Assert
                Assert.IsTrue(originalContent is { Count: > 0 });
                Assert.IsTrue(reverseContent is { Count: > 0 });
                originalContent.ToList().ForEach(line =>
                {
                    var originalIndex = originalContent.IndexOf(line);
                    var reversedIndex = originalIndex;
                    var toCharArray = line.ToCharArray();
                    Array.Reverse(toCharArray);
                    if (content.StrategyName == FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString())
                    {
                        if (originalIndex == 0)
                        {
                            reversedIndex = originalContent.Count - 1;
                        }
                        else if (originalIndex == originalContent.Count - 1)
                        {
                            reversedIndex = 0;
                        }
                    }

                    var valueToCompare = reverseContent[reversedIndex];
                    Assert.IsTrue(valueToCompare.Equals(new string(toCharArray)));
                });
            }
            catch (Exception ex)
            {

            }
        }

        //Reverse Every Line and Test Greater than 3 Line Content
        [Test]
        public void ReverseAndTestGreaterThan3LineContent()
        {
            try
            {
                //Assign
                var stringContent = new List<string>
                {
                    "Test Line 1",
                    "Test Line 2",
                    "Test Line 3",
                    "Test Line 4"
                };

                //Act
                var content = new FileContent(stringContent.ToArray());
                var originalContent = content.OriginalContent;
                var reverseContent = content.ReversedContent;

                //Assert
                Assert.IsTrue(originalContent is { Count: > 0 });
                Assert.IsTrue(reverseContent is { Count: > 0 });
                originalContent.ToList().ForEach(line =>
                {
                    var originalIndex = originalContent.IndexOf(line);
                    var reversedIndex = originalIndex;
                    var toCharArray = line.ToCharArray();
                    Array.Reverse(toCharArray);
                    if (content.StrategyName == FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString())
                    {
                        if (originalIndex == 0)
                        {
                            reversedIndex = originalContent.Count - 1;
                        }
                        else if (originalIndex == originalContent.Count - 1)
                        {
                            reversedIndex = 0;
                        }
                    }

                    var valueToCompare = reverseContent[reversedIndex];
                    Assert.IsTrue(valueToCompare.Equals(new string(toCharArray)));
                });
            }
            catch (Exception ex)
            {

            }
        }

        //Reverse Every Line and Test 3 Line Content
        [Test]
        public void ReadFromFile3LineContentAndReverse()
        {
            try
            {
                //Assign
                var read = _fileservice.ReadFile("C:\\UnitTestFile\\File.txt");

                //Act
                var content = new FileContent(read);
                var originalContent = content.OriginalContent;
                var reverseContent = content.ReversedContent;

                //Assert
                Assert.IsTrue(originalContent is { Count: > 0 });
                Assert.IsTrue(reverseContent is { Count: > 0 });
                originalContent.ToList().ForEach(line =>
                {
                    var originalIndex = originalContent.IndexOf(line);
                    var reversedIndex = originalIndex;
                    var toCharArray = line.ToCharArray();
                    Array.Reverse(toCharArray);
                    if (content.StrategyName == FileContent.ReverseStrategies.SwapAndReverseStrategy.ToString())
                    {
                        if (originalIndex == 0)
                        {
                            reversedIndex = originalContent.Count - 1;
                        }
                        else if (originalIndex == originalContent.Count - 1)
                        {
                            reversedIndex = 0;
                        }
                    }
                    var valueToCompare = reverseContent[reversedIndex];
                    Assert.IsTrue(valueToCompare.Equals(new string(toCharArray)));
                });
            }
            catch (Exception ex)
            {

            }
        }
    }
}