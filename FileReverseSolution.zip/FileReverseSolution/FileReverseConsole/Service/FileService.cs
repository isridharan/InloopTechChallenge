﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileReverseConsole;

namespace FileReverseConsole.Service
{
    public interface IFileService
    {
        public string[] ReadFile(string filepath);
    }

    public class FileService: IFileService
    {
        public string[] ReadFile(string filepath)
        {
            //throw new NotImplementedException();
            string[] lines = System.IO.File.ReadAllLines(filepath);
            if (lines.Length == 0)
                throw new EmptyFileException($"There is no content in the file {filepath} and the file is empty.");
            return lines;
        }
    }
}
