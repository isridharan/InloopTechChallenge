﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace FileReverseConsole.Domain
{
    public class FileContent
    {
        private readonly Strategy _strategy;
        public FileContent(string[] lines)
        {
            if (lines.Length == 0)
                throw new CannotCreateFileContentWithoutLines("File content cannot be created without lines");
            this.OriginalContent = new List<string>();
            lines.ToList().ForEach(line =>
            {
                OriginalContent.Add(line);
            });
            _strategy  = SetStrategy();
        }

        private Strategy SetStrategy()
        {
            if (this.OriginalContent.Count > 1) return new SwapAndReverseStrategy();
            return new ReverseStrategy();
        }

        public string StrategyName => _strategy.GetType().Name;

        public List<string> OriginalContent { get; protected set; }

        public List<string> ReversedContent => _strategy.Reverse(OriginalContent);

        public enum ReverseStrategies {
            [EnumMember(Value = "SwapAndReverseStrategy")]
            SwapAndReverseStrategy,
            [EnumMember(Value = "ReverseStrategy")]
            ReverseStrategy
        }
    }
}
