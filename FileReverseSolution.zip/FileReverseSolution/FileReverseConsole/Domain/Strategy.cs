﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileReverseConsole.Domain
{
   public abstract class Strategy
   {
       public abstract List<string> Reverse(List<string> content);
   }

   public class ReverseStrategy : Strategy
   {
       public override List<string> Reverse(List<string> content)
       {
           var reverseContent = new List<string>();
           content.ForEach(line =>
           {
               var lineCharArray = line.ToCharArray();
               Array.Reverse(lineCharArray);
               reverseContent.Add(new string(lineCharArray));
           });
           return reverseContent;
        }
   }

   public class SwapAndReverseStrategy : Strategy
   {
       public override List<string> Reverse(List<string> content)
       {
           var reverseContent = new List<string>();
           content.ForEach(line =>
           {
               var lineCharArray = line.ToCharArray();
               Array.Reverse(lineCharArray);
               reverseContent.Add(new string(lineCharArray));
           });
           return SwapFirstAndLastLine(reverseContent);
       }

       private List<string> SwapFirstAndLastLine(List<string> content)
       {
           var tmp = content[content.Count -1];
           content[content.Count - 1] = content[0];
           content[0] = tmp;
           return content;
        }
   } 
}
