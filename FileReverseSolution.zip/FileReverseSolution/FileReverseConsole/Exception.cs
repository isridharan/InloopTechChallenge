﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileReverseConsole
{
    public class EmptyFileException : System.Exception
    {
        public EmptyFileException(string message)
            : base(message)
        {
        }
    }

    public class CannotCreateFileContentWithoutLines : System.Exception
    {
        public CannotCreateFileContentWithoutLines(string message)
            : base(message)
        {
        }
    }
}
